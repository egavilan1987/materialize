# materialize-playlist
All course files for the Materialize CSS playlist on The Net Ninja YouTube channel.
Make sure you select the correct branch in the top-left, for the code for each lesson :)
